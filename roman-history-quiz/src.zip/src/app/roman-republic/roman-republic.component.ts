
import { Component } from '@angular/core';

@Component({
  selector: 'app-roman-republic',
  templateUrl: './roman-republic.component.html',
  styleUrls: ['./roman-republic.component.css']
})
export class RomanRepublicComponent {}
