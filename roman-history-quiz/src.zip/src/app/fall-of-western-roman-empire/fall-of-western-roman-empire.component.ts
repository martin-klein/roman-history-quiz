
import { Component } from '@angular/core';

@Component({
  selector: 'app-fall-of-western-roman-empire',
  templateUrl: './fall-of-western-roman-empire.component.html',
  styleUrls: ['./fall-of-western-roman-empire.component.css']
})
export class FallOfWesternRomanEmpireComponent {}
