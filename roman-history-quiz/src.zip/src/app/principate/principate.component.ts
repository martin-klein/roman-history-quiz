
import { Component } from '@angular/core';

@Component({
  selector: 'app-principate',
  templateUrl: './principate.component.html',
  styleUrls: ['./principate.component.css']
})
export class PrincipateComponent {}
