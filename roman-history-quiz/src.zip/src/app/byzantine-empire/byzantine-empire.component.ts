
import { Component } from '@angular/core';

@Component({
  selector: 'app-byzantine-empire',
  templateUrl: './byzantine-empire.component.html',
  styleUrls: ['./byzantine-empire.component.css']
})
export class ByzantineEmpireComponent {}
