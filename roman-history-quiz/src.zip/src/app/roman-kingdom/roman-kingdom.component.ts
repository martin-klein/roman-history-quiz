
import { Component } from '@angular/core';

@Component({
  selector: 'app-roman-kingdom',
  templateUrl: './roman-kingdom.component.html',
  styleUrls: ['./roman-kingdom.component.css']
})
export class RomanKingdomComponent {}
