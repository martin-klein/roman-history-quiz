
import { Component } from '@angular/core';

@Component({
  selector: 'app-dominate',
  templateUrl: './dominate.component.html',
  styleUrls: ['./dominate.component.css']
})
export class DominateComponent {}
